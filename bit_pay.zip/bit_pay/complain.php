<!DOCTYPE html>
<html>

<head>
  <title>complain form</title>
<link rel="stylesheet" href="assets/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

  <link href="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.6.1/css/bootstrap4-toggle.min.css" rel="stylesheet">
    
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans&display=swap" rel="stylesheet"> 
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <script src="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.6.1/js/bootstrap4-toggle.min.js"></script>


    <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet"> 
<link rel="stylesheet" type="text/css" href="assets/css/new.css">


 <style>

textarea:focus, 
textarea.form-control:focus, 
input.form-control:focus, 
input[type=text]:focus, 
input[type=password]:focus, 
input[type=email]:focus, 
input[type=number]:focus, 
[type=text].form-control:focus, 
[type=password].form-control:focus, 
[type=email].form-control:focus, 
[type=tel].form-control:focus, 
[contenteditable].form-control:focus select:focus {
  box-shadow: inset 0 -1px 0 #ddd;

}

.form-control {
  font-size: 14px;
}


body{
font-family: 'IBM Plex Sans', sans-serif;
}

a{
  text-decoration: none;
}


</style>

<!--jquery form-->

 <script type="text/javascript">
$(document).ready(function(){
    $("form").on("submit", function(event){
        event.preventDefault();
 
        var formValues= $(this).serialize();
 
        $.post("verify_complain.php", formValues, function(data){
            // Display the returned data in browser
            $("#result").html(data);
        });
    });
});
</script>

</head>
<body>
<section id="sec_1" style="margin-top: 0px; margin-bottom: 0px ">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-6">   

<div class="container" style="padding-top: 70px">
        <h1 style="font-family: 'Pacifico', cursive;"><b>Help improve on our design!</b></h1>
        </h1>

<form>
 
  <div class="row" style="padding-top:30px">

    <div id="result"><br></div>

  <div class="col">
    <input type="email" class="form-control" id="validationCustom01" placeholder="Enter Email Address" aria-label="Email Address" style="height: 50px" name="email" value="<?php if(isset($_POST['email'])) echo($_POST['email'])?>" required>
  </div>
  <div class="col">
   <input type="tel" class="form-control" id="validationCustom02" placeholder="Enter Phone Number" aria-label="Phone Number" style="height: 50px" name="phone" value="<?php if(isset($_POST['Phone'])) echo($_POST['Phone'])?>" required>
  </div>

<div class="form-group">

  <br>
 <select class="form-select" aria-label="Default select example" id="validationCustom04" style="height: 50px" name="via" required>
  <option selected disabled value="">Choose...</option>
  <option value="1">Via Phone</option>
  <option value="2">Via Email</option>
</select>
</div>

<div class="form-group">
  <br>
    <label for="exampleFormControlTextarea1">Drop your complain</label>
    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="complain" value="<?php if(isset($_POST['complains'])) echo($_POST['complains'])?>" required>   </textarea>
  </div>

</div>
<spam style="padding-top: 10px;"></spam>
<br>
 <spam style="padding-right: 30px; padding-bottom: 10px"> <button type="submit" class="btn btn-primary" style="height: 50px; width: 100%;">Submit</button></spam>
 <input type="hidden" name="submitted" id="submitted" value="1">
<br>
 <p><a href="http://localhost/projects/web/">Back to the main site</a></p>
</form>

      </div>
    </div>


      <div class="col-md-6"> 
        <img class="float-end d-none d-sm-block" src="images/globe@2x.png" width="100%" height="600px" style="padding-top: 70px">
      </div>


</div>
</div>

</section>

