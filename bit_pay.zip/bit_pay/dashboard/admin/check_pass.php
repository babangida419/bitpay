<?php
include_once('../../auth_session.php');
// an array for error messages
$email = $_SESSION["email"];
$errors = array();
include_once('../../SqlConnect.php');


 $confirmPassword = $_POST['confirmPassword'];
 #$pass = $_POST['pass'];
$newPassword = $_POST['newPassword'];
$dddd = md5($newPassword);



if(count($_POST)>0) {
$result = mysqli_query($conn,"SELECT *from accounts WHERE email='" . $email . "'");
$row=mysqli_fetch_array($result);

if (!empty($_POST['confirmPassword']) ){ 

mysqli_query($conn,"UPDATE accounts set pass='" . $dddd . "' WHERE email='" . $email . "'");

header('Location:change_pass.php?success=passUpdated');

} else{

 header('Location:change_pass.php?errors=invalidInput');

}}

 ?>