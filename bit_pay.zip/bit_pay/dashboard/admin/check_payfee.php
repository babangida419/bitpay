<?php
include_once('../../auth_session.php');
// an array for error messages
$email = $_SESSION["email"];
$errors = array();
include_once('../../SqlConnect.php');


