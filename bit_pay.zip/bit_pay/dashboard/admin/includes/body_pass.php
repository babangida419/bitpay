 <?php

include_once('../../SqlConnect.php');

$email= $_SESSION['email'];
?>

 <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <a class="navbar-brand" href="javascript:;">Payments</a>
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="sr-only">Toggle navigation</span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end">
            <form class="navbar-form">
              <div class="input-group no-border">
                <!-- <input type="text" value="" class="form-control" placeholder="Search...">
                 <i class="material-icons">search</i>-->
                  <div class="ripple-container"></div>
                </button>
              </div>
            </form>
             <ul class="navbar-nav">
              <li class="nav-item">

              <?php

$q = "SELECT * FROM accounts WHERE email='$email'";

$r = @mysqli_query($conn, $q);
$row = mysqli_fetch_assoc($r);

echo "Welcome on Board &nbsp <span style=\"color:#0b5ed7;\">";
 print_r($row['first_name']); echo "&nbsp"; print_r($row['last_name']);

?>
  

                </a>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <i class="material-icons">notifications</i>
                  <span class="notification">5</span>
                  <p class="d-lg-none d-md-block">
                    Some Actions
                  </p>
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                  <a class="dropdown-item" href="#">Mike John responded to your email</a>
                  <a class="dropdown-item" href="#">You have 5 new tasks</a>
                  <a class="dropdown-item" href="#">You're now friend with Andrew</a>
                  <a class="dropdown-item" href="#">Another Notification</a>
                  <a class="dropdown-item" href="#">Another One</a>
                </div>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link" href="javascript:;" id="navbarDropdownProfile" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <i class="material-icons">person</i><img src="images/caret-down-fill.svg">
                  <p class="d-lg-none d-md-block">
                    Account
                  </p>
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownProfile">
                  <a class="dropdown-item" href="#">Profile</a>
                  <a class="dropdown-item" href="#">Settings</a>
                  <div class="dropdown-divider"></div>
                  <a class="dropdown-item" href="../../logout.php">Log out</a>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <!-- End Navbar -->
  
  <!-- form -->
<div class="content">
        <div class="container-fluid">
          <div class="row">

 <div class="col-md-4">
                     
<div class="card" style="width: 18rem;">
  <div class="card-body">
    <h5 class="card-title" style="padding-bottom:15px">Profile Settings</h5>
    <a href="Profile.php"><p style="padding-top:15px">Edit Profile</p></a>
   <button type="button" class="btn btn-primary">Change your password</button>
 
  </div>
</div>
</div>


            <div class="col-md-8">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Change Password</h4>
                 
                </div>


                <?php
                if (isset($_GET['success'])){
                    if($_GET['success'] == 'passUpdated'){

                      echo '<small class="alert text-success"> Password updated Successfully</small><hr>';

                    }
                  }
                        ?>

<?php
                if (isset($_GET['errors'])){
                    if($_GET['errors'] == 'invalidInput'){

                      echo '<small class="alert text-danger"> Invalid Password</small><hr>';

                    }
                  }
                        ?>



<form method="POST" action="check_pass.php" enctype="multipart/form-data">

                <div class="card-body">
                    <div class="row"  style="padding-top: 10px">
                       <div class="col-md-12" style="margin-top: 10px">
                        <div class="form-group">
                          <label class="bmd-label-floating">Current Password</label>
                          <input type="password" class="form-control" name="currentPassword" required>
                        </div>
                      </div>

                      <div class="col-md-12">
                        <div class="form-group">
                          <label class="bmd-label-floating">New Pawword</label>
                          <input type="password" class="form-control" name="newPassword" required>
                        </div>
                      </div>

                      <div class="col-md-12">
                        <div class="form-group">
                          <label class="bmd-label-floating">Comfirm Password</label>
                          <input type="password" name="confirmPassword" class="form-control" required>
                        </div>
                      </div>

                        <button type="submit" name="update" value="update" class="btn btn-primary" style="width: 100%">Save changes</button>
                      </div>

                </div>
              </form>
