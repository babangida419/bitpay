 <?php

include_once('../../SqlConnect.php');

$email= $_SESSION['email'];
?>

 <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <a class="navbar-brand" href="javascript:;">Payments</a>
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="sr-only">Toggle navigation</span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end">
            <form class="navbar-form">
              <div class="input-group no-border">
                <!-- <input type="text" value="" class="form-control" placeholder="Search...">
                 <i class="material-icons">search</i>-->
                  <div class="ripple-container"></div>
                </button>
              </div>
            </form>
             <ul class="navbar-nav">
              <li class="nav-item">

              <?php

$q = "SELECT * FROM accounts WHERE email='$email'";

$r = @mysqli_query($conn, $q);
$row = mysqli_fetch_assoc($r);

echo "Welcome on Board &nbsp <span style=\"color:#0b5ed7;\">";
 print_r($row['first_name']); echo "&nbsp"; print_r($row['last_name']);

?>
  

                </a>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <i class="material-icons">notifications</i>
                  <span class="notification">5</span>
                  <p class="d-lg-none d-md-block">
                    Some Actions
                  </p>
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                  <a class="dropdown-item" href="#">Mike John responded to your email</a>
                  <a class="dropdown-item" href="#">You have 5 new tasks</a>
                  <a class="dropdown-item" href="#">You're now friend with Andrew</a>
                  <a class="dropdown-item" href="#">Another Notification</a>
                  <a class="dropdown-item" href="#">Another One</a>
                </div>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link" href="javascript:;" id="navbarDropdownProfile" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <i class="material-icons">person</i><img src="images/caret-down-fill.svg">
                  <p class="d-lg-none d-md-block">
                    Account
                  </p>
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownProfile">
                  <a class="dropdown-item" href="#">Profile</a>
                  <a class="dropdown-item" href="#">Settings</a>
                  <div class="dropdown-divider"></div>
                  <a class="dropdown-item" href="../../logout.php">Log out</a>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <!-- End Navbar -->
  
  <!-- form -->
<div class="content">
        <div class="container-fluid">
          <div class="row">



 <div class="col-md-4">
                     
<div class="card" style="width: 18rem;">
  <div class="card-body">
    <h5 class="card-title" style="padding-bottom:15px">Profile Settings</h5>
   <button type="button" class="btn btn-primary">Edit Profile</button>
 <a href="change_pass.php"><p style="padding-top:15px">  Change your password</p></a>
  </div>
</div>
</div>


            <div class="col-md-8">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Update Profile</h4>
                  
                </div>

                <div class="card-body">

                <?php
                if (isset($_GET['success'])){
                    if($_GET['success'] == 'userUpdated'){

                      echo '<small class="alert text-success"> User updated Successfully</small><hr>';

                    }
                  }
                        ?>


                        <?php 

              if (isset($_GET['errors'])){
                    if($_GET['errors'] == 'invalidInput'){

                      echo '<small class="alert text-danger"> error missing input</small><hr>';

                    }
                  }
                      ?>



                  <form method="POST" action="update_profile_chk.php" enctype="multipart/form-data">

<div id="result"></div>
                     <?php
                        $currentUser = $_SESSION['email'];
                        $sql = "SELECT * FROM accounts WHERE email ='$currentUser'";

                        $gotResuslts = mysqli_query($conn,$sql);

                        if($gotResuslts){
                            if(mysqli_num_rows($gotResuslts)>0){
                                while($row = mysqli_fetch_array($gotResuslts)){
                                    //print_r($row['user_name']);
                                    ?>



                    <div class="row"  style="padding-top: 30px">
                       <div class="col-md-6" style="margin-top: 20px">
                        <div class="form-group">
                          <label class="bmd-label-floating">Fist Name</label>
                          <input type="text" class="form-control" name="Updatefname" value="<?php echo $row['first_name']; ?>" required>
                        </div>
                      </div>

                      <div class="col-md-6" style="margin-top: 20px">
                        <div class="form-group">
                          <label class="bmd-label-floating">Last Name</label>
                          <input type="text" class="form-control" name="Updatelname" value="<?php echo $row['last_name']; ?>" required>
                        </div>
                      </div>

                      <div class="col-md-6" style="margin-top: 20px">
                        <div class="form-group">
                          <label class="bmd-label-floating">Email</label>
                          <input type="text" name="Updateemail" class="form-control" value="<?php echo $row['email']; ?>" required>
                        </div>
                      </div>

                      <div class="col-md-6" style="margin-top: 20px">
                        <div class="form-group">
                          <label class="bmd-label-floating">Password</label>
                          <input type="password" disabled name="Updatepass" class="form-control" value="<?php echo $row['pass']; ?>" required>
                          <a href="change_pass.php"><small><span class="float-right" style="color: red">Resert Password</span></small></a>
                        </div>
                      </div>
                        <button type="submit" name="update" value="update" class="btn btn-primary" style="width: 100%">Update Profile</button>
                      </div>
<?php
                                }
                            }
                        }


                    ?>
                      
                    </form>
                </div>
                </div>
                </div>
                <!-- form end-->

                  
                
