<?php
//include auth_session.php file on all user panel pages
include("auth_session.php");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Dashboard - Client area</title>
    <link rel="stylesheet" href="style.css" />
</head>
<body>

  <?php
#$page_title = "Admin_dashboard";
include_once ('includes/header_payments.php');
include_once ('includes/body_payments.php');
?>
    



<?php
include_once ('includes/footer.php');
?>
