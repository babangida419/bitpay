<?php
include_once('../../auth_session.php');
// an array for error messages
$errors = array();
include_once('../../SqlConnect.php');

 $fname = $_POST['Updatefname'];
 $lname = $_POST['Updatelname'];
 $email = $_POST['Updateemail'];
 $password = $_POST['Updatepass'];
 


if(isset ($_POST['update'])){

  //checkmate fname
  if(empty($_POST['Updatefname'])){
    $fname = $_POST['Updatefname'];
    $errors[] = "No input for first name";
  } else{
    $fname = trim($_POST['Updatefname']);
  }


  //checkmate lname
  if(empty($_POST['Updatelname'])){
    $lname = $_POST['Updatelname'];
    $errors[] = "No input for Last name";
  } else{
    $lname = trim($_POST['Updatelname']);
  }

  

  //checkmate email
  if(empty($_POST['Updateemail'])){
    $email = $_POST['Updateemail'];
    $errors[] = "No input for email";
  } else{
    $email = trim($_POST['Updateemail']);
  }


if ( !empty($_POST['Updateemail']) && !empty($_POST['Updatelname']) && !empty($_POST['Updatefname']) ){

   $sql = "UPDATE accounts SET email = '$email', first_name ='$fname', last_name='$lname' WHERE email = '$email'";

                        $results = mysqli_query($conn,$sql);
                        header('Location:profile.php?success=userUpdated');

  
} else{
   
header('Location:profile.php?errors=invalidInput');

}                       
         }           
          
                

?>