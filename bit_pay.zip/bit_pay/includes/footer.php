<footer class="footer" style="background-color: #0c188c; color: #fff">
<section id="sec_4">

	<div class="container" style="padding-top: 40px; padding-bottom: 50px">

<div class="row">

<div class="col-md-4">

<b>	ABOUT US </b><br><br>

Every group of form fields should reside in a element. Bootstrap provides no default styling for the element, but there are some powerful browser features that are provided by. 


</div>

<div class="col-md-2">
	<b>	QUICK LINKS </b><br><br>

<p><a href="#"> >-- Home</a></p>
<p><a href="#"> >-- About</a></p>
<p><a href="#"> >-- Login</a></p>
<p><a href="#"> >-- Apply</a></p>
<p><a href="complain.php"> >-- Complains</a></p>


</div>

<div class="col-md-2">
	<b> SUPPORT </b><br><br>

<p><a href="#"> >-- Contact</a></p>
<p><a href="#"> >-- Support ticket</a></p>
<p><a href="#"> >-- Doc</a></p>
<p><a href="#"> >-- Resources</a></p>



</div>
<div class="col-md-4">
<b>	SUBSCRIBE </b><br><br>	
<p>Subscribe to our mailing list to get the latest updates</p>

<form>
  <div class="row">
    <div class="col-md-12 col-sm-12" style="margin-bottom: 20px">
      <input type="email" class="form-control" placeholder="Enter Your Email Address" aria-label="Phone Number" style="height: 50px">
    </div>
    <div class="col">
      <spam> <button type="submit" class="btn btn-primary" style="height: 50px; width: 100%;">Subscribe</button></spam>
    </div>
  </div>
</form>



</div>
</div>
</div>
<a href="#" id="toTopBtn" class="cd-top text-replace js-cd-top cd-top--is-visible cd-top--fade-out" data-abc="true"></a>

</section>
</footer>
 <script>
function myFunction() {
   var element = document.body;
   element.classList.toggle("dark-mode");
}
</script>

<script type="text/javascript">
	
$(document).ready(function() {
$(window).scroll(function() {
if ($(this).scrollTop() > 20) {
$('#toTopBtn').fadeIn();
} else {
$('#toTopBtn').fadeOut();
}
});

$('#toTopBtn').click(function() {
$("html, body").animate({
scrollTop: 0
}, 1000);
return false;
});
});

</script>

<script type="text/javascript">
  


  var TxtType = function(el, toRotate, period) {
        this.toRotate = toRotate;
        this.el = el;
        this.loopNum = 0;
        this.period = parseInt(period, 10) || 2000;
        this.txt = '';
        this.tick();
        this.isDeleting = false;
    };

    TxtType.prototype.tick = function() {
        var i = this.loopNum % this.toRotate.length;
        var fullTxt = this.toRotate[i];

        if (this.isDeleting) {
        this.txt = fullTxt.substring(0, this.txt.length - 1);
        } else {
        this.txt = fullTxt.substring(0, this.txt.length + 1);
        }

        this.el.innerHTML = '<span class="wrap">'+this.txt+'</span>';

        var that = this;
        var delta = 200 - Math.random() * 100;

        if (this.isDeleting) { delta /= 2; }

        if (!this.isDeleting && this.txt === fullTxt) {
        delta = this.period;
        this.isDeleting = true;
        } else if (this.isDeleting && this.txt === '') {
        this.isDeleting = false;
        this.loopNum++;
        delta = 500;
        }

        setTimeout(function() {
        that.tick();
        }, delta);
    };

    window.onload = function() {
        var elements = document.getElementsByClassName('typewrite');
        for (var i=0; i<elements.length; i++) {
            var toRotate = elements[i].getAttribute('data-type');
            var period = elements[i].getAttribute('data-period');
            if (toRotate) {
              new TxtType(elements[i], JSON.parse(toRotate), period);
            }
        }
        // INJECT CSS
        var css = document.createElement("style");
        css.type = "text/css";
        css.innerHTML = ".typewrite > .wrap { border-right: 0.08em solid #fff}";
        document.body.appendChild(css);
    };
</script>

</body>
<script type="text/javascript" src="assets/js/jquery.js"></script>
<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
</html>