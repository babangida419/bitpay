<!DOCTYPE html>
<html>
<head>
	<title>	<?php echo "$page_title" ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<link href="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.6.1/css/bootstrap4-toggle.min.css" rel="stylesheet">
    
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans&display=swap" rel="stylesheet"> 
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <script src="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.6.1/js/bootstrap4-toggle.min.js"></script>


    <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet"> 
<link rel="stylesheet" type="text/css" href="assets/css/new.css">


 <style>

textarea:focus, 
textarea.form-control:focus, 
input.form-control:focus, 
input[type=text]:focus, 
input[type=password]:focus, 
input[type=email]:focus, 
input[type=number]:focus, 
[type=text].form-control:focus, 
[type=password].form-control:focus, 
[type=email].form-control:focus, 
[type=tel].form-control:focus, 
[contenteditable].form-control:focus {
  box-shadow: inset 0 -1px 0 #ddd;

}

.form-control {
  font-size: 14px;
}

.dark-mode{
  background-color: black;
  color: white;
}

.dark-mode a{
  color: white;
}


.dark-mode .btn{
  background-color: white !important;
  color: black;
}

.btnbg{
  background-color: #032554 !important;
  color: black;

 background-color: #032554 !important;
}


.dark-mode .back  {
	background-color: black;
	background-color: rgba(0, 0, 0, 0.37);
}

.dark-mode .footer  {
	background-color: black !important;
	
}


.dark-mode .sec_new {
  background-color: #131720 !important;
  
}


body{
font-family: 'IBM Plex Sans', sans-serif;
}

a{
	text-decoration: none;
}


.dark-mode .cccc{
  display: none ;
}


.dark-mode .navbar-brand{
  background-image: url(images/11.png);
   background-repeat:no-repeat;
   width:250px;
height: 55px;
background-size: contain;
margin-top: 10px !important;
}

</style>
<script type="text/javascript" src="assets/js/jquery.js"></script>
<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-expand-lg">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php"><img class="cccc" src="images/1.png" alt="Responsive image" width="200px"></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"><img src="images/align-justify.png"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarText">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-md-5">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">How it works</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Pricing Plan</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">F.A.Q</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Contact us</a>
        </li>
      </ul>
      <span class="navbar-text">

     	<input type="checkbox" checked data-toggle="toggle" data-on="Light-mode" data-off="Dark-mode" data-width="150px" data-height="40px" data-onstyle="light" data-offstyle="dark" onchange="myFunction()">&nbsp; &nbsp;

       <!-- <button type="button" class="btn btn-light shadow p-3 mb-5 bg-white rounded" style="position: relative; top: 20px">New Client Registration</button>-->

<a href="register.php"><button type="button" class="btn btn-primary" style="height: 40px;">Create free account</button></a>
      </span>
    </div>
  </div>
</nav>

