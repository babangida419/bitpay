
	<?php
$page_title = "Home";
include_once ('includes/header.php');
?>

<section id="sec_1" style="margin-top: 30px;">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-6 col-sm-12">   

<div class="container" style="padding-top: 40px">


				<h1 style="font-family: 'Roboto', sans-serif;"><b>Do more with your Bit-<span style="color: #84c225">Pay</span></b></h1>

				<h1 style="font-family: 'Roboto', sans-serif; font-size: 30px">Convert your Bitcoin to 
  <a href="" style="color:#84c225" class="typewrite" data-period="2000" data-type='[ "Pay school fee", "Shop online", "Recharge cards"]'>With B-itpay
    <span class="wrap"></span>
  </a>
</h1>

<div style="margin-top: 70px"></div>


<form method="post" action="logincheck.php" class="row g-3 shadow p-3 mb-5 bg-white rounded">

  <div class="row" style="padding-top:30px">
<div id="result"><br></div>
  <div class="col-md-6 col-sm-12" style="padding-bottom: 10px">
    <input type="email" class="form-control" placeholder="Email" name="email" aria-label="Email Address" style="height: 50px" value="<?php if(isset($_POST['email'])) echo($_POST['email'])?>" required/>
  </div>
  <div class="col">
   <input type="password" class="form-control" placeholder="Password" name="pass" aria-label="Password" style="height: 50px" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" value="<?php if(isset($_POST['pass'])) echo($_POST['pass'])?>" required>
</select>
  </div>
</div>
<spam style="padding-top: 5px;"></spam>

 <spam style="padding-left: 10px; padding-right: 30px; padding-bottom: 30px"> <button type="submit" name="submit" class="btn btn-primary" style="height: 50px; width: 100%;">Log in</button></spam>
 <input type="hidden" name="submitted" id="submitted" value="1">
</form>

			</div>
		</div>


			<div class="col-md-6"> 
				<img class="float-end d-none d-sm-block mt-2 mb-20" src="images/cv.webp" width="95%" height="470px" style="padding-top: 40px">
			</div>


</div>
</div>

</section>

<div style="margin-top: 50px"></div>


<div class="sec_new container-fluid" style="background-color:#032554; padding: 40px;">

	<h1 style="font-family: 'Roboto', sans-serif; color: white"><b>Do more with your Bit-pay</b></h1>
	<p style="color: white">Buy both Bitcoin Cash (BCH) and Bitcoin (BTC) now using a credit or debit card.</p>

<div class="row">
  <div class="col-md-3" style="padding-bottom: 10px">
   <select class="form-select" aria-label="Default select example" id="validationCustom04" style="height: 50px" name="country" required>
  <option selected disabled value="">BITCOIN BTC</option>
  <option value="BTC">Bitcoin Cash</option>
  <option value="DH">Dash</option>
</select>
  </div>

  <div class="col-md-3" style="padding-bottom: 10px">
    <select class="form-select" aria-label="Default select example" id="validationCustom04" style="height: 50px" name="country" required>
  <option selected disabled value="">Country</option>
  <option value="NG">Nigeria</option>
  <option value="GH">Ghana</option>
</select>
  </div>

  <div class="col-md-3" style="padding-bottom: 10px">
    <input type="text" class="form-control" placeholder="BTC ID" aria-label="BTC ID" style="height: 50px;">
  </div>


<div class="col-md-3" style="padding-bottom: 10px">
  <spam style="padding-bottom: 30px"> <button type="submit" name="submit" class="btn btn-primary" style="height: 50px; width: 100%;">Pay With BTC</button></spam>
 <input type="hidden" name="submitted" id="submitted" value="1">

</div>
</div>
<p style="padding-bottom: 40px"></p>
</div>

<p style="padding-bottom: 40px"></p>

<section class="sec_2">
	
	<div class="container">
	<p align="center" style="font-size: 60px; font-weight: 500; padding-top: 20px; font-family: 'Roboto', sans-serif;"> App Services</p>
	  </div>

	  <div class="container">
	  	<div class="row">

	  		<div class="col-md-2 col-sm-12">
	<p align="center" style="font-size: 18px; font-weight: 500;"> </div>

<div class="col-md-8 col-sm-12">
	<p align="center" style="font-size: 16px; font-weight: 500;"> 
		Every group of form fields should reside in a  element. Bootstrap provides no default styling for the  element, but there are some powerful browser features that are provided by.

	</p></div>

	<div class="col-md-2 col-sm-12">
	<p align="center" style="font-size: 18px; font-weight: 500;"> </div>

	  </div>
	  </div>


<div class="container">
	<div class="row">

		<div class="col-md-6">	

			<img src="images/df.png" style="padding-bottom: 20px; width: 100%;">	

		</div>

		<div class="col-md-6 col-sm-12"> 

			<h1 style="padding-top:70px; padding-bottom: 10px; font-size: 50px; font-family: 'Roboto', sans-serif;">Easy and Perfect solution </h1>

			<p>

				You can now buy your electricity token or pay your bill in just two steps. Other benefits you get; detailed reports and notifications on the go...

				<br><br>
			<p>	<img src="images/a.png">  &nbsp; &nbsp;  <img src="images/a.png"> </p>
				

			</p>
			</div>


</div>
</div>
</section>

<p style="padding-bottom: 20px"></p>

<section id="sec_3" style="background-image: url(images/2.jpg); background-attachment: fixed; background-repeat:no-repeat; background-size:cover;">
	

<div class="container-fluid back" style="padding-top: 100px; padding-bottom:100px; padding-left:70px;">
<div class="row">
	<div class="col-md-6 col-sm-12">

<h1 class="done" style="font-size: 50px; font-family: 'Roboto', sans-serif;">Easy and Perfect solution </h1>
<br />

<p style="font-size: 16px">Resolve any Payment Issue</p>

<form>
  <div class="row">
    <div class="col-md-6 col-sm-12" style="padding-bottom: 10px">
      <input type="text" class="form-control" placeholder="Transaction ID" aria-label="Transaction ID" style="height: 50px">
    </div>
    <div class="col">
      <spam style=""> <button type="submit" class="btn btn-primary" style="height: 50px; width: 100%;">Resolve Issue</button></spam>
    </div>
  </div>
</form>

	</div>


	<div class="col-md-6"></div>

</div>
</div>

</section>



<div id="sec_4" class="sec_new" style="padding-top:70px;">

  <div class="container">
  <div class="row">

<div class="col-md-4">

  <h3 class="done" style="font-size: 50px; font-family: 'Roboto', sans-serif;">  Global scale</h3>
   <p style="font-family: 'Roboto', sans-serif;"> The backbone for internet business</p>
   For ambitious companies around the world, Stripe makes moving money as simple, borderless, and programmable as the rest of the internet. Our teams are based in dozens of offices around the world and we process hundreds of billions of dollars each year for startups to Fortune 500s. 
</div>
</div>
</div>



<div class="container" style="padding-top: 50px">
  <div class="row">

<div class="col-md-4">
<img src="images/settings.png"><br>

<b><p style="padding-top: 20px">Close to the metal</p></b>
From direct integrations with card networks and banks to checkout flows in the browser, we operate on and optimize at every level of the financial stack.

</div>


<div class="col-md-4">
<img src="images/cup.png"><br>
 <b><p style="padding-top: 20px">Close to the metal</p></b>
From direct integrations with card networks and banks to checkout flows in the browser, we operate on and optimize at every level of the financial stack.


</div>


<div class="col-md-4">
<img src="images/icn.png"><br>
 <b><p style="padding-top: 20px">Close to the metal</p></b>
From direct integrations with card networks and banks to checkout flows in the browser, we operate on and optimize at every level of the financial stack.


</div>

</div>
</div>

<p style="padding-bottom: 80px"></p>


<?php
include_once ('includes/footer.php');
?>


<!--jquery form-->

 <script type="text/javascript">
$(document).ready(function(){
    $("form").on("submit", function(event){
        event.preventDefault();
 
        var formValues= $(this).serialize();
 
        $.post("logincheck.php", formValues, function(data){
        

            // Display the returned data in browser
            if (data == 1) {
            	 window.location = 'dashboard/admin/admin.php';
            
            } else{
            	$("#result").html(data);
            }
            

        });
    });
});
</script>

