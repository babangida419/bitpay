<!DOCTYPE html>
<html>

<head>
  <title>complain form</title>
<link rel="stylesheet" href="assets/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

  <link href="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.6.1/css/bootstrap4-toggle.min.css" rel="stylesheet">
    
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans&display=swap" rel="stylesheet"> 
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <script src="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.6.1/js/bootstrap4-toggle.min.js"></script>


    <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet"> 
<link rel="stylesheet" type="text/css" href="assets/css/new.css">


 <style>

textarea:focus, 
textarea.form-control:focus, 
input.form-control:focus, 
input[type=text]:focus, 
input[type=password]:focus, 
input[type=email]:focus, 
input[type=number]:focus, 
[type=text].form-control:focus, 
[type=password].form-control:focus, 
[type=email].form-control:focus, 
[type=tel].form-control:focus, 
[contenteditable].form-control:focus select:focus {
  box-shadow: inset 0 -1px 0 #ddd;

}

.form-control {
  font-size: 14px;
}


body{
font-family: 'IBM Plex Sans', sans-serif;
}

a{
  text-decoration: none;
}


</style>

<!--jquery form-->

 <script type="text/javascript">
$(document).ready(function(){
    $("form").on("submit", function(event){
        event.preventDefault();
 
        var formValues= $(this).serialize();
 
        $.post("logincheck.php", formValues, function(data){
        

            // Display the returned data in browser
            if (data == 1) {
               window.location = 'dashboard/admin/admin.php';
            
            } else{
              $("#result").html(data);
            }
            

        });
    });
});
</script>


</head>
<body>
<section id="sec_1" style="margin-top: 0px; margin-bottom: 0px ">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-6">   
<a href="index.php"><img src="images/1.png" width="150px"></a>
<div class="container" style="padding-top: 70px">
        <h1 class="mb-5" style="font-family: 'Pacifico', cursive;"><b>Login to your Pay account</b></h1>
        </h1>



<form method="post" action="logincheck.php" class="row g-3 shadow p-3 mb-5 bg-white rounded">

  <div class="" style="padding-top:50px">

<div id="result"><br></div>
  <div class="col-md-12 col-sm-12" style="padding-bottom: 30px">
    <input type="email" class="form-control" placeholder="Email" name="email" aria-label="Email Address" style="height: 50px" value="<?php if(isset($_POST['email'])) echo($_POST['email'])?>" required/>
  </div>
  <div class="col-md-12 col-sm-12">
   <input type="password" class="form-control" placeholder="Password" name="pass" aria-label="Password" style="height: 50px" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" value="<?php if(isset($_POST['pass'])) echo($_POST['pass'])?>" required>
</select>
  </div>
</div>
<spam style="padding-top: 10px;"></spam>

 <spam style="padding-left: 10px; padding-right: 30px; padding-bottom: 30px"> <button type="submit" name="submit" class="btn btn-primary" style="height: 50px; width: 100%;">Log in</button></spam>
 <input type="hidden" name="submitted" id="submitted" value="1">
</form>
 Don't have an account, <a href="register.php" class="text-danger">Register</a> <spam class="float-end"><a href="password-reset.php"><b>Forgot your password?</b></a></spam>
      </div>
    </div>


      <div class="col-md-6"> 
        <img class="float-end d-none d-sm-block" src="images/globe@2x.png" width="100%" height="500px" style="padding-top: 100px">
      </div>


</div>
</div>

</section>

