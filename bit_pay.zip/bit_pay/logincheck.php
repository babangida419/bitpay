<?php
    require('SqlConnect.php');
    session_start();


    // When form submitted, check and create user session.
    if (isset($_POST['email'])) {
        $email = stripslashes($_REQUEST['email']);    // removes backslashes
        $email = mysqli_real_escape_string($conn, $email);
        $pass = stripslashes($_REQUEST['pass']);
        $pass = mysqli_real_escape_string($conn, $pass);

        // Check user is exist in the database

         $query    = "SELECT * FROM accounts WHERE email='$email' AND pass='" . sha1($pass) . "'";
        $result = mysqli_query($conn, $query);
        $rows = mysqli_num_rows($result);
        if ($rows == 1) {
            $_SESSION['email'] = $email;
            // Redirect to user dashboard page
            #header("Location: dashboard.php");
            echo 1;
            exit();
        } else {
            echo " <div class=\"alert alert-danger alert-dismissible fade show\" role=\"alert\">Incorrect Email or Password</div> ";
        }
    } else {

    }
?>